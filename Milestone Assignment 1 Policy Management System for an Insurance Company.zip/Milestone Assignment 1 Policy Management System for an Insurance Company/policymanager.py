from PolicyHolder import PolicyHolder
from Product import Product
from Payment import Payment

class PolicyManager:
    def __init__(self):
        self.policy_holders = {}
        self.products = {}
        self.payments = {}

    def add_policy_holder(self, policy_holder_id, name, address, contact_number):
        policy_holder = PolicyHolder(policy_holder_id, name, address, contact_number)
        self.policy_holders[policy_holder_id] = policy_holder
        print(f"Policy holder {name} added.")

    def suspend_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].suspend()

    def add_product(self, product_id, name, description, price):
        product = Product(product_id, name, description, price)
        self.products[product_id] = product
        print(f"Product {name} added.")

    def add_payment(self, payment_id, policy_holder_id, amount, date):
        payment = Payment(payment_id, policy_holder_id, amount, date)
        self.payments[payment_id] = payment
        print(f"Payment of {amount} added for policy holder {policy_holder_id}.")
from PolicyHolder import PolicyHolder
from Product import Product
from Payment import Payment

class PolicyManager:
    def __init__(self):
        self.policy_holders = {}
        self.products = {}
        self.payments = {}

    def add_policy_holder(self, policy_holder_id, name, address, contact_number):
        if policy_holder_id in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} already exists.")
            return
        policy_holder = PolicyHolder(policy_holder_id, name, address, contact_number)
        self.policy_holders[policy_holder_id] = policy_holder
        print(f"Policy holder {name} added.")

    def suspend_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].suspend()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def reactivate_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].reactivate()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def add_product(self, product_id, name, description, price):
        if product_id in self.products:
            print(f"Product with ID {product_id} already exists.")
            return
        product = Product(product_id, name, description, price)
        self.products[product_id] = product
        print(f"Product {name} added.")

    def add_payment(self, payment_id, policy_holder_id, amount, date):
        if payment_id in self.payments:
            print(f"Payment with ID {payment_id} already exists.")
            return
        if policy_holder_id not in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")
            return
        payment = Payment(payment_id, policy_holder_id, amount, date)
        self.payments[payment_id] = payment
        print(f"Payment of {amount} added for policy holder {policy_holder_id}.")

    def get_policy_holder_info(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            print(self.policy_holders[policy_holder_id])
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def get_product_info(self, product_id):
        if product_id in self.products:
            print(self.products[product_id])
        else:
            print(f"Product with ID {product_id} does not exist.")

    def get_payment_info(self, payment_id):
        if payment_id in self.payments:
            print(self.payments[payment_id])
        else:
            print(f"Payment with ID {payment_id} does not exist.")
from PolicyHolder import PolicyHolder
from Product import Product
from Payment import Payment

class PolicyManager:
    def __init__(self):
        self.policy_holders = {}
        self.products = {}
        self.payments = {}

    def add_policy_holder(self, policy_holder_id, name, address, contact_number):
        if policy_holder_id in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} already exists.")
            return
        policy_holder = PolicyHolder(policy_holder_id, name, address, contact_number)
        self.policy_holders[policy_holder_id] = policy_holder
        print(f"Policy holder {name} added.")

    def suspend_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].suspend()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def reactivate_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].reactivate()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def add_product(self, product_id, name, description, price):
        if product_id in self.products:
            print(f"Product with ID {product_id} already exists.")
            return
        product = Product(product_id, name, description, price)
        self.products[product_id] = product
        print(f"Product {name} added.")

    def add_payment(self, payment_id, policy_holder_id, amount, date):
        if payment_id in self.payments:
            print(f"Payment with ID {payment_id} already exists.")
            return
        if policy_holder_id not in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")
            return
        payment = Payment(payment_id, policy_holder_id, amount, date)
        self.payments[payment_id] = payment
        self.policy_holders[policy_holder_id].add_payment(payment)
        print(f"Payment of {amount} added for policy holder {policy_holder_id}.")

    def process_payment(self, payment_id):
        if payment_id in self.payments:
            self.payments[payment_id].process_payment()
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def add_penalty(self, payment_id, penalty_amount):
        if payment_id in self.payments:
            self.payments[payment_id].add_penalty(penalty_amount)
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def send_reminder(self, payment_id):
        if payment_id in self.payments:
            self.payments[payment_id].send_reminder()
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def get_policy_holder_info(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            print(self.policy_holders[policy_holder_id])
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def get_product_info(self, product_id):
        if product_id in self.products:
            print(self.products[product_id])
        else:
            print(f"Product with ID {product_id} does not exist.")

    def get_payment_info(self, payment_id):
        if payment_id in self.payments:
            print(self.payments[payment_id])
        else:
            print(f"Payment with ID {payment_id} does not exist.")
from PolicyHolder import PolicyHolder
from Product import Product
from Payment import Payment

class PolicyManager:
    def __init__(self):
        self.policy_holders = {}
        self.products = {}
        self.payments = {}

    def add_policy_holder(self, policy_holder_id, name, address, contact_number):
        if policy_holder_id in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} already exists.")
            return
        policy_holder = PolicyHolder(policy_holder_id, name, address, contact_number)
        self.policy_holders[policy_holder_id] = policy_holder
        print(f"Policy holder {name} added.")

    def suspend_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].suspend()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def reactivate_policy_holder(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            self.policy_holders[policy_holder_id].reactivate()
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def add_product(self, product_id, name, description, price):
        if product_id in self.products:
            print(f"Product with ID {product_id} already exists.")
            return
        product = Product(product_id, name, description, price)
        self.products[product_id] = product
        print(f"Product {name} added.")

    def update_product(self, product_id, name, description, price):
        if product_id in self.products:
            self.products[product_id].update_details(name, description, price)
        else:
            print(f"Product with ID {product_id} does not exist.")

    def suspend_product(self, product_id):
        if product_id in self.products:
            self.products[product_id].suspend()
        else:
            print(f"Product with ID {product_id} does not exist.")

    def reactivate_product(self, product_id):
        if product_id in self.products:
            self.products[product_id].reactivate()
        else:
            print(f"Product with ID {product_id} does not exist.")

    def add_payment(self, payment_id, policy_holder_id, amount, date):
        if payment_id in self.payments:
            print(f"Payment with ID {payment_id} already exists.")
            return
        if policy_holder_id not in self.policy_holders:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")
            return
        payment = Payment(payment_id, policy_holder_id, amount, date)
        self.payments[payment_id] = payment
        self.policy_holders[policy_holder_id].add_payment(payment)
        print(f"Payment of {amount} added for policy holder {policy_holder_id}.")

    def process_payment(self, payment_id):
        if payment_id in self.payments:
            self.payments[payment_id].process_payment()
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def add_penalty(self, payment_id, penalty_amount):
        if payment_id in self.payments:
            self.payments[payment_id].add_penalty(penalty_amount)
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def send_reminder(self, payment_id):
        if payment_id in self.payments:
            self.payments[payment_id].send_reminder()
        else:
            print(f"Payment with ID {payment_id} does not exist.")

    def get_policy_holder_info(self, policy_holder_id):
        if policy_holder_id in self.policy_holders:
            print(self.policy_holders[policy_holder_id])
        else:
            print(f"Policy holder with ID {policy_holder_id} does not exist.")

    def get_product_info(self, product_id):
        if product_id in self.products:
            print(self.products[product_id])
        else:
            print(f"Product with ID {product_id} does not exist.")

    def get_payment_info(self, payment_id):
        if payment_id in self.payments:
            print(self.payments[payment_id])
        else:
            print(f"Payment with ID {payment_id} does not exist.")
