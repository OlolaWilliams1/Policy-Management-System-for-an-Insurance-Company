from PolicyHolder import PolicyHolder
from Product import Product
from Payment import Payment
from PolicyManager import PolicyManager
from datetime import date

# Initialize the policy manager
policy_manager = PolicyManager()

# Add products
policy_manager.add_product(101, "Health Insurance", "Comprehensive health insurance plan", 500)
policy_manager.add_product(102, "Life Insurance", "Term life insurance plan", 300)

# Add policyholders
policy_manager.add_policy_holder(1, "John Doe", "123 Elm Street", "555-1234")
policy_manager.add_policy_holder(2, "Jane Smith", "456 Oak Street", "555-5678")

# Add payments
policy_manager.add_payment(201, 1, 500, date.today())
policy_manager.add_payment(202, 2, 500, date.today())

# Process payments
policy_manager.process_payment(201)
policy_manager.process_payment(202)

# Display account details
policy_manager.get_policy_holder_info(1)
policy_manager.get_policy_holder_info(2)
