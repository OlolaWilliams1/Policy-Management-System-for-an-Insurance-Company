class Payment:
    def __init__(self, payment_id, policy_holder_id, amount, date):
        self.payment_id = payment_id
        self.policy_holder_id = policy_holder_id
        self.amount = amount
        self.date = date

    def update_payment(self, amount, date):
        self.amount = amount
        self.date = date
        print(f"Payment {self.payment_id} has been updated.")
class Payment:
    def __init__(self, payment_id, policy_holder_id, amount, date):
        self.payment_id = payment_id
        self.policy_holder_id = policy_holder_id
        self.amount = amount
        self.date = date

    def update_payment(self, amount, date):
        self.amount = amount
        self.date = date
        print(f"Payment {self.payment_id} has been updated.")

    def __str__(self):
        return f"Payment(id={self.payment_id}, policy_holder_id={self.policy_holder_id}, amount={self.amount}, date={self.date})"
class Payment:
    def __init__(self, payment_id, policy_holder_id, amount, date, status='Pending'):
        self.payment_id = payment_id
        self.policy_holder_id = policy_holder_id
        self.amount = amount
        self.date = date
        self.status = status

    def process_payment(self):
        self.status = 'Completed'
        print(f"Payment {self.payment_id} has been processed.")

    def add_penalty(self, penalty_amount):
        self.amount += penalty_amount
        print(f"Penalty of {penalty_amount} added to payment {self.payment_id}. New amount: {self.amount}")

    def send_reminder(self):
        print(f"Reminder sent for payment {self.payment_id} of amount {self.amount}.")

    def update_payment(self, amount, date):
        self.amount = amount
        self.date = date
        print(f"Payment {self.payment_id} has been updated.")

    def __str__(self):
        return f"Payment(id={self.payment_id}, policy_holder_id={self.policy_holder_id}, amount={self.amount}, date={self.date}, status={self.status})"
class Payment:
    def __init__(self, payment_id, policy_holder_id, amount, date, status='Pending'):
        self.payment_id = payment_id
        self.policy_holder_id = policy_holder_id
        self.amount = amount
        self.date = date
        self.status = status

    def process_payment(self):
        self.status = 'Completed'
        print(f"Payment {self.payment_id} has been processed.")

    def add_penalty(self, penalty_amount):
        self.amount += penalty_amount
        print(f"Penalty of {penalty_amount} added to payment {self.payment_id}. New amount: {self.amount}")

    def send_reminder(self):
        print(f"Reminder sent for payment {self.payment_id} of amount {self.amount}.")

    def update_payment(self, amount, date):
        self.amount = amount
        self.date = date
        print(f"Payment {self.payment_id} has been updated.")

    def __str__(self):
        return f"Payment(id={self.payment_id}, policy_holder_id={self.policy_holder_id}, amount={self.amount}, date={self.date}, status={self.status})"
