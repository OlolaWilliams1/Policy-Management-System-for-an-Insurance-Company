class Product:
    def __init__(self, product_id, name, description, price):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price

    def update_details(self, name, description, price):
        self.name = name
        self.description = description
        self.price = price
        print(f"Product {self.product_id} details have been updated.")
class Product:
    def __init__(self, product_id, name, description, price):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price

    def update_details(self, name, description, price):
        self.name = name
        self.description = description
        self.price = price
        print(f"Product {self.product_id} details have been updated.")

    def __str__(self):
        return f"Product(id={self.product_id}, name={self.name}, price={self.price})"
class Product:
    def __init__(self, product_id, name, description, price):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price

    def update_details(self, name, description, price):
        self.name = name
        self.description = description
        self.price = price
        print(f"Product {self.product_id} details have been updated.")

    def __str__(self):
        return f"Product(id={self.product_id}, name={self.name}, price={self.price})"
class Product:
    def __init__(self, product_id, name, description, price):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.active = True

    def update_details(self, name, description, price):
        self.name = name
        self.description = description
        self.price = price
        print(f"Product {self.product_id} details have been updated.")

    def suspend(self):
        self.active = False
        print(f"Product {self.name} has been suspended.")

    def reactivate(self):
        self.active = True
        print(f"Product {self.name} has been reactivated.")

    def __str__(self):
        status = 'Active' if self.active else 'Suspended'
        return f"Product(id={self.product_id}, name={self.name}, price={self.price}, status={status})"
