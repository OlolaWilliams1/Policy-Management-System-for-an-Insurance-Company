class PolicyHolder:
    def __init__(self, policy_holder_id, name, address, contact_number):
        self.policy_holder_id = policy_holder_id
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.active = True

    def suspend(self):
        self.active = False
        print(f"Policy holder {self.name} has been suspended.")

    def activate(self):
        self.active = True
        print(f"Policy holder {self.name} has been activated.")

    def update_contact_info(self, address, contact_number):
        self.address = address
        self.contact_number = contact_number
        print(f"Policy holder {self.name}'s contact information has been updated.")
class PolicyHolder:
    def __init__(self, policy_holder_id, name, address, contact_number):
        self.policy_holder_id = policy_holder_id
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.active = True

    def suspend(self):
        self.active = False
        print(f"Policy holder {self.name} has been suspended.")

    def reactivate(self):
        self.active = True
        print(f"Policy holder {self.name} has been reactivated.")

    def update_contact_info(self, address, contact_number):
        self.address = address
        self.contact_number = contact_number
        print(f"Policy holder {self.name}'s contact information has been updated.")

    def __str__(self):
        status = 'Active' if self.active else 'Suspended'
        return f"PolicyHolder(id={self.policy_holder_id}, name={self.name}, status={status})"
class PolicyHolder:
    def __init__(self, policy_holder_id, name, address, contact_number):
        self.policy_holder_id = policy_holder_id
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.active = True
        self.payments = []

    def suspend(self):
        self.active = False
        print(f"Policy holder {self.name} has been suspended.")

    def reactivate(self):
        self.active = True
        print(f"Policy holder {self.name} has been reactivated.")

    def update_contact_info(self, address, contact_number):
        self.address = address
        self.contact_number = contact_number
        print(f"Policy holder {self.name}'s contact information has been updated.")

    def add_payment(self, payment):
        self.payments.append(payment)
        print(f"Payment {payment.amount} added for policy holder {self.name}.")

    def __str__(self):
        status = 'Active' if self.active else 'Suspended'
        return f"PolicyHolder(id={self.policy_holder_id}, name={self.name}, status={status})"
class PolicyHolder:
    def __init__(self, policy_holder_id, name, address, contact_number):
        self.policy_holder_id = policy_holder_id
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.active = True
        self.payments = []

    def suspend(self):
        self.active = False
        print(f"Policy holder {self.name} has been suspended.")

    def reactivate(self):
        self.active = True
        print(f"Policy holder {self.name} has been reactivated.")

    def update_contact_info(self, address, contact_number):
        self.address = address
        self.contact_number = contact_number
        print(f"Policy holder {self.name}'s contact information has been updated.")

    def add_payment(self, payment):
        self.payments.append(payment)
        print(f"Payment {payment.amount} added for policy holder {self.name}.")

    def __str__(self):
        status = 'Active' if self.active else 'Suspended'
        return f"PolicyHolder(id={self.policy_holder_id}, name={self.name}, status={status})"
